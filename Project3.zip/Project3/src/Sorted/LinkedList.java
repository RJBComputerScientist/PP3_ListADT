package Sorted;

public class LinkedList {

}
