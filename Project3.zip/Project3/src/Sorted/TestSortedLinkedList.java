package Sorted;

import car.Car;
import Sorted.SortedLinkedList;
import java.lang.*;

public class TestSortedLinkedList {

public static void main(String[] args) {
		
		Car MainCar = new Car("Infiniti", "Q50", 2018);
		Car Mini = new Car("Mini", "S Wagon", 2020);
		Car PrizeCar = new Car("Suzuki", "Grand Luxe", 2014);
		Car ThrowBack = new Car("ASA", "1000 GT", 1967);
		Car BackUpCar = new Car("Jaguar", "Sports Sedan", 2015);
		Car OldCar = new Car("Daytona", "Triumph", 2005);
		
		SortedLinkedList<Car> CarOrder = new SortedLinkedList();
		
		Car car1 = BackUpCar;
		Car car2 = PrizeCar;
		System.out.println(System.nanoTime());
		CarOrder.add(MainCar);
		System.out.println(System.nanoTime());
		CarOrder.add(Mini);
		System.out.println(System.nanoTime());
		CarOrder.add(PrizeCar);
		System.out.println(System.nanoTime());
		CarOrder.add(ThrowBack);
		System.out.println(System.nanoTime());
		CarOrder.add(BackUpCar);
		System.out.println(System.nanoTime());
		CarOrder.add(OldCar);
		System.out.println(System.nanoTime());
		CarOrder.remove(Mini);
		System.out.println(System.nanoTime());
		CarOrder.contains(MainCar);
		System.out.println(System.nanoTime());
		//CarOrder.size();
		System.out.println(CarOrder.isEmpty() ? "My lot is empty?": "Tell me my size" 
		+ CarOrder.size());
		System.out.println(System.nanoTime());
		//CarOrder.isEmpty();
		CarOrder.resetIterator();
		CarOrder.resetBackIterator();
		CarOrder.find(PrizeCar);
		System.out.println(System.nanoTime());
		CarOrder.find2(OldCar);
		System.out.println(System.nanoTime());
		CarOrder.getNextItem();
		CarOrder.getPrevItem();
		
		//System.out.println(System.nanoTime());
		
		//System.out.println(System.currentTimeMillis());
		/*
		if (car1.equals(car2)) {
			System.out.println(car1 + " is equal to " + car2);
		}
		else {
			System.out.println(car1 + " is not equal to " + car2);
		}
		
		if (car1.compareTo(car2) == 0) {
			System.out.println(car1 + " is equal to " + car2);
		}
		else {
			if (car1.compareTo(car2) < 0) {
				System.out.println(car1 + " was made before " + car2);
			}
			else {
				System.out.println(car1 + " made more recently than " + car2);
			}*/
			
		}

		
		
		
		

	}


