package Sorted;

import car.Car;
import Sorted.ArraySortedList;

public class TestArraySortedList {

public static void main(String[] args) {
		
	Car BrokenCar = new Car("Mazda", "3", 2018);
	Car Giveaway = new Car("Tesla", "Model S", 2020);
	Car StolenCar1 = new Car("Honda", "Accord", 2017);
	Car StolenCar2 = new Car("DeLorean", "DHC-12", 1981);
	Car CarFromLot = new Car("Bentley", "Continental", 2020);
	Car BadCar = new Car("Chevy", "Equinox", 1997);
	
	Car car1 = Giveaway;
	Car car2 = StolenCar2;
	
		
		ArraySortedList<Car> CarOption = new ArraySortedList();
		
				}

		
		
		
		

	}


