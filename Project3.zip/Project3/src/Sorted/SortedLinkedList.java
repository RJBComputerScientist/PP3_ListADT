package Sorted;

import interfaces.ListInterface;
import car.Car;
import nodes.DLLNode;
import nodes.LLNode;

import java.lang.Comparable;

public class SortedLinkedList<E> implements ListInterface<E> {

	protected DLLNode<E> FrontCar = null, BackCar = null, iterator = null, BackIterator = null, location = null;

	protected boolean found, DirtyFlag = true;
	protected Comparable[] TempList = null;
	protected int position, numElements = 0;

	public SortedLinkedList() {
		super();
	}

	public SortedLinkedList(int initialCapacity) {
		super();
	}

	/*
	 * protected void enlarge() { E[] newBiggerArray = (E[]) new Object[list.length
	 * + initialCapacity]; for (int i = 0; i < numElements; i++) { newBiggerArray[i]
	 * = list[i]; } list = newBiggerArray; }
	 */

	@Override
	public void add(E element) {
		DLLNode<E> temp = new DLLNode<E>(element);

		if (FrontCar == null) {
			System.out.println("List empty.  Adding first element.");
			FrontCar = temp;
			BackCar = temp;
			//temp.setNext(temp);
		} else if(((Comparable)element).compareTo(FrontCar.getInfo()) <= 0){
			System.out.println("Adding to front of list.");
			FrontCar.setPrev(temp);
			temp.setNext(FrontCar);
			FrontCar = temp;
		} else if(((Comparable)element).compareTo(BackCar.getInfo()) >= 0){
			System.out.println("Adding to rear of list.");
			BackCar.setNext(temp);
			temp.setPrev(BackCar);
			BackCar = temp;
		} else {
			//int AddSpot = 0;
			DLLNode<E> cur = FrontCar;
			while (cur != BackCar) {
				System.out.println("Adding to middle of list.");
				if (((Comparable) element).compareTo(cur.getInfo()) > 0) {
			//		AddSpot++;
					cur = cur.getNext();
				} else {
					cur.getPrev().setNext(temp);
					cur.setPrev(temp);
					temp.setNext(cur); 
					temp.setPrev(cur.getPrev());
					//BackCar.setPrev(temp);
					break;
				}
			}
		}
		++numElements;
		System.out.println(toString());
	}

	@Override
	public boolean remove(E element) {
		find(element);
		System.out.println(System.nanoTime());
		if (found) {
			if (FrontCar != null) {
				if (FrontCar.getInfo().equals(element)) {
					FrontCar = FrontCar.getNext();
					BackCar.setNext(FrontCar);
					return found;
				} else {
					DLLNode<E> Current = FrontCar;
					while (!(Current.getNext().getInfo().equals(element)) && Current.getNext() != BackCar) {
						Current = Current.getNext();
					}
					if (Current.getNext().getInfo().equals(element)) {
						Current.setNext(Current.getNext().getNext());
						return found;
					}
				}
			}
		}
		numElements--;
		return false;

		/*
		 * if(found) { if(location.getPrev() != null) {
		 * location.getPrev().setNext(location.getNext()); } else { FrontCar =
		 * location.getNext(); location.getNext().setPrev(null); } if(location.getNext()
		 * != null) { location.getNext().setPrev(location.getPrev()); } else { BackCar =
		 * location.getPrev(); location.getPrev().setNext(null); } DirtyFlag = true; }
		 * return found;
		 */

	}

	@Override
	public int size() {
		int numElements = 0;
		DLLNode<E> temp = FrontCar;

		while (temp != null) {
			numElements++;
			temp = temp.getNext();
		}
		return numElements;
	}

	@Override
	public boolean isEmpty() {

		return FrontCar == null;
	}

	@Override
	public boolean contains(E element) {
		find(element);
		return found;
	}

	@Override
	public E get(E element) {
		find(element);
		E temp = null;
		if (found) {
			temp = location.getInfo();
		}
		return temp;
	}

	@Override
	public void resetIterator() {
		iterator = FrontCar;

	}

	public void resetBackIterator() {
		BackIterator = BackCar;
	}

	@Override
	public E getNextItem() {
		E temp = null;
		if (iterator != null) {
			temp = iterator.getInfo();
			iterator = iterator.getNext();
		}

		return temp;
	}

	public E getPrevItem() {
		E temp = null;
		if (BackIterator != null) {
			temp = BackIterator.getInfo();
			BackIterator = BackIterator.getPrev();
		}

		return temp;

	}

	public void find(E element) {
		found = false;
		location = FrontCar;
		System.out.println("start");
		while (location != null) {
			// System.out.println(((Car) location.getInfo()).getYear());
			if (location.getInfo().equals(element)) {
				found = true;
				return;
			}
			location = location.getNext();
		}
		System.out.println("end");

	}

	public void find2(E element) {
		if (DirtyFlag == true) {
			TempList = new Comparable[size()];
			DLLNode<E> temp = FrontCar;
			for (int i = 0; i < TempList.length; i++) {
				TempList[i] = (Comparable) temp.getInfo();
				temp = temp.getNext();
			}
			DirtyFlag = false;
		}
		int low = 0;
		int high = TempList.length - 1;
		position = -1;
		found = false;

		int mid = (low + high) / 2;
		while (low <= high && found == false) {
			mid = (low + high) / 2;
			if (TempList[mid].equals(element)) {
				found = true;
				position = mid;
			} else if (TempList[mid].compareTo(element) < 0) {
				high = mid - 1;
			} else if (TempList[mid].compareTo(element) > 0) {
				low = mid + 1;
			}
		}
	}

	public String toString() { // How do you make two strings in the "toString()" method
		String CarOrder = "Here is your garage";
		DLLNode<E> Car = FrontCar;//BackCar.getNext();
		//CarOrder = " " + CarOrder;
		System.out.println("HERE");
		while (Car != null) {
			String temp = Car.getInfo().toString();
			//System.out.println(temp);
			CarOrder = CarOrder + " " + temp;
			Car = Car.getNext();
		}
		System.out.println("DONE");
		//CarOrder = CarOrder + " " + Car.getInfo();
		return CarOrder;
		// CarSelection ALSO "Here is the car you selected";
	}
}

